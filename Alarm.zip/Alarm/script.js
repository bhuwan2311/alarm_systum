// Function to update the clock display
function updateClock() {
    const now = new Date();
    const timeElement = document.getElementById("time");
    timeElement.textContent = now.toLocaleTimeString();
}

// Function to add an alarm to the list
function addAlarm(hour, minute, ampm) {
    const alarmList = document.getElementById("alarm-list");
    const alarmTime = `${hour}:${minute} ${ampm}`;
    const listItem = document.createElement("li");
    listItem.textContent = alarmTime;
    alarmList.appendChild(listItem);
}

// Function to set an alarm
function setAlarm() {
    const hourInput = document.getElementById("hour");
    const minuteInput = document.getElementById("minute");
    const ampmSelect = document.getElementById("ampm");

    const hour = hourInput.value;
    const minute = minuteInput.value;
    const ampm = ampmSelect.value;

    if (hour && minute) {
        addAlarm(hour, minute, ampm);
        // Store the alarm in local storage
        const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
        alarms.push({ hour, minute, ampm });
        localStorage.setItem("alarms", JSON.stringify(alarms));

        // Clear input fields
        hourInput.value = "";
        minuteInput.value = "";
    }
}

// Function to load alarms from local storage
function loadAlarms() {
    const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
    alarms.forEach((alarm) => {
        addAlarm(alarm.hour, alarm.minute, alarm.ampm);
    });
}

// Event listeners
document.getElementById("set-alarm").addEventListener("click", setAlarm);
document.getElementById("delete-alarms").addEventListener("click", () => {
    localStorage.removeItem("alarms");
    document.getElementById("alarm-list").innerHTML = "";
});

// Initialize the clock and load alarms on page load
updateClock();
loadAlarms();
setInterval(updateClock, 1000); // Update the clock every second
// Function to display the list of set alarms
function displayAlarms() {
    const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
    const alarmList = document.getElementById("alarm-list");
    alarmList.innerHTML = "";

    alarms.forEach((alarm, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${alarm.hour}:${alarm.minute} ${alarm.ampm}`;
        
        // Add an "Edit" button for each alarm
        const editButton = document.createElement("button");
        editButton.textContent = "Edit";
        editButton.addEventListener("click", () => editAlarm(index));
        
        // Add a "Delete" button for each alarm
        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", () => deleteAlarm(index));
        
        listItem.appendChild(editButton);
        listItem.appendChild(deleteButton);
        
        alarmList.appendChild(listItem);
    });
}

// Function to edit an alarm
function editAlarm(index) {
    const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
    const alarmToEdit = alarms[index];
    
    if (alarmToEdit) {
        const hourInput = document.getElementById("hour");
        const minuteInput = document.getElementById("minute");
        const ampmSelect = document.getElementById("ampm");
        
        hourInput.value = alarmToEdit.hour;
        minuteInput.value = alarmToEdit.minute;
        ampmSelect.value = alarmToEdit.ampm;
        
        // Remove the edited alarm from the list
        alarms.splice(index, 1);
        localStorage.setItem("alarms", JSON.stringify(alarms));
        displayAlarms();
    }
}

// Function to delete an alarm
function deleteAlarm(index) {
    const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
    alarms.splice(index, 1);
    localStorage.setItem("alarms", JSON.stringify(alarms));
    displayAlarms();
}

// Update the "Set Alarm" functionality to handle both setting new alarms and editing existing ones
function setAlarm() {
    const hourInput = document.getElementById("hour");
    const minuteInput = document.getElementById("minute");
    const ampmSelect = document.getElementById("ampm");
    
    const hour = hourInput.value;
    const minute = minuteInput.value;
    const ampm = ampmSelect.value;
    
    if (hour && minute) {
        const alarms = JSON.parse(localStorage.getItem("alarms")) || [];
        const newAlarm = { hour, minute, ampm };
        
        // Check if an alarm is being edited
        if (hourInput.dataset.editing) {
            const editingIndex = parseInt(hourInput.dataset.editing);
            alarms[editingIndex] = newAlarm;
            delete hourInput.dataset.editing;
        } else {
            alarms.push(newAlarm);
        }
        
        localStorage.setItem("alarms", JSON.stringify(alarms));
        hourInput.value = "";
        minuteInput.value = "";
        ampmSelect.value = "AM";
        
        displayAlarms();
    }
}

// Event listeners
document.getElementById("set-alarm").addEventListener("click", setAlarm);

// Initialize the clock and load alarms on page load
updateClock();
displayAlarms();
setInterval(updateClock, 1000); // Update the clock every second
